function calculate(x){
    display.value += x;  /* x+=5 means x=x+5 */
}